﻿GAMEPLAY CAPTURES

Approved captures will use this folder when supplied:

Tactical Combat
A tactical encounter showing movement, Action Points, terrain, height, status effects, and enemy behavior.

Exploration
Exploring the roads, ruins, and wilderness around Thornvale.

Optimized GIF previews, MP4 files, and still-image downloads are included. The captures originate from approved Steam media.
