﻿GAMEPLAY CAPTURES

Approved captures will use this folder when supplied:

Tactical Combat
Grid-based tactical combat featuring positioning, Action Points, terrain, height, status effects, and enemy behavior.

Shimmer Distortion
A glimpse of the Shimmer and its visual distortion effects.

Character Customization
The character creation system used to shape the player's version of Caelis.

Exploration
Exploration through the hand-built world of The Cradle of Life.

GIF previews and WebM, MP4, or still-image downloads may be included. No temporary footage has been manufactured.
