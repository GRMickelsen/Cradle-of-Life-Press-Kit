﻿GAMEPLAY CAPTURES

Approved captures will use this folder when supplied:

Tactical Combat
A tactical encounter showing movement, Action Points, terrain, height, status effects, and enemy behavior.

Shimmer Distortion
A glimpse of the Shimmer and its visual distortion effects.

Character Customization
A look at Caelis's character creation options.

Exploration
Exploring the roads, ruins, and wilderness around Thornvale.

GIF previews and WebM, MP4, or still-image downloads may be included. No temporary footage has been manufactured.
