﻿THE CRADLE OF LIFE - PRESS KIT

The Cradle of Life is a dark-fantasy tactical RPG developed by Garrett Mickelsen and published by Milo's Games.

Steam and demo:
https://store.steampowered.com/app/4580240/The_Cradle_of_Life/

Release status: Coming soon
Platforms: Windows and macOS
Press contact: PUBLIC PRESS EMAIL PENDING

This archive was assembled from current public Steam materials and repository main on September 9, 2026.
Please preserve screenshot aspect ratios and do not imply that unannounced content is included in the current demo.
